plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.sonicd06.game"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sonicd06.game"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "0.1"
    }
}
