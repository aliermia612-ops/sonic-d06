package com.sonicd06.game
import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
 private lateinit var game: GameView
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
  val root=FrameLayout(this); game=GameView(this); root.addView(game)
  val hud=TextView(this).apply { text="SONIC D06  •  DEMO 0.1"; textSize=16f; setTextColor(0xffffffff.toInt()); setPadding(20,12,20,12) }
  root.addView(hud,FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.CENTER_HORIZONTAL))
  val bar=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
  fun control(label:String,cmd:String) {
   val b=Button(this).apply {
    text=label; alpha=.85f
    setOnTouchListener { _,e ->
     when(e.action) { MotionEvent.ACTION_DOWN -> game.setControl(cmd,true); MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL -> game.setControl(cmd,false) }
     true
    }
   }
   bar.addView(b,LinearLayout.LayoutParams(0,145,1f))
  }
  control("◀","left"); control("▶","right"); control("JUMP","jump"); control("BOOST","boost"); control("ATTACK","attack")
  root.addView(bar,FrameLayout.LayoutParams(-1,155,Gravity.BOTTOM))
  setContentView(root)
 }
 override fun onPause(){super.onPause(); if(::game.isInitialized) game.onPause()}
 override fun onResume(){super.onResume(); if(::game.isInitialized) game.onResume()}
}
