package com.sonicd06.game
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class GameRenderer:GLSurfaceView.Renderer {
 private lateinit var cube:Mesh
 private lateinit var ball:Mesh
 private lateinit var ring:Mesh
 private var program=0
 private val proj=FloatArray(16); private val view=FloatArray(16); private val vp=FloatArray(16); private val model=FloatArray(16)
 @Volatile private var left=false; @Volatile private var right=false; @Volatile private var jump=false
 @Volatile private var boost=false
 private var x=0f; private var y=0f; private var vy=0f; private var z=0f; private var last=System.nanoTime()
 fun controls(n:String,d:Boolean){ when(n){"left"->left=d;"right"->right=d;"jump"->jump=d;"boost"->boost=d} }
 override fun onSurfaceCreated(gl:GL10?,config:EGLConfig?){
  GLES20.glClearColor(.42f,.72f,.94f,1f); GLES20.glEnable(GLES20.GL_DEPTH_TEST)
  val vs="attribute vec3 aPosition; uniform mat4 uMvp; void main(){gl_Position=uMvp*vec4(aPosition,1.0);}"
  val fs="precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}"
  program=program(vs,fs); cube=Mesh.cube(); ball=Mesh.sphere(); ring=Mesh.ring()
 }
 override fun onSurfaceChanged(gl:GL10?,w:Int,h:Int){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(proj,0,58f,w.toFloat()/h.coerceAtLeast(1),.1f,100f)}
 override fun onDrawFrame(gl:GL10?){
  GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
  val now=System.nanoTime(); val dt=((now-last)/1e9).toFloat().coerceIn(0f,.04f);last=now
  val speed=if(boost)8f else 4f
  if(left)x-=speed*dt;if(right)x+=speed*dt;x=x.coerceIn(-5f,5f)
  if(jump&&y==0f)vy=8f
  vy-=19f*dt;y=(y+vy*dt).coerceAtLeast(0f);if(y==0f)vy=0f
  z-=speed*dt*.2f;if(z< -8f)z=0f
  Matrix.setLookAtM(view,0,x*.15f,4.2f,9.5f,x*.1f,0f,-2f,0f,1f,0f)
  Matrix.multiplyMM(vp,0,proj,0,view,0)
  draw(cube,0f,-.5f,-4f,14f,.35f,30f,.2f,.48f,.22f)
  for(i in -2..2)draw(cube,i*3f,-.12f,-12f,2f,.45f,2f,.35f,.42f,.55f)
  draw(ball,x,y+.62f,0f,.48f,.62f,.42f,.04f,.28f,.95f)
  draw(ball,x,y+1.15f,.03f,.32f,.32f,.3f,.08f,.42f,1f)
  for(i in 0..7)draw(ring,((i%3)-1)*1.5f,1f,-2f-i*2.1f-(z%2.1f),.48f,.48f,.08f,1f,.78f,.04f)
  for(i in 0..3)draw(cube,if(i%2==0)-2.2f else 2.2f,.35f,-7f-i*5f,.6f,.7f,.6f,.85f,.18f,.12f)
 }
 private fun draw(m:Mesh,x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,r:Float,g:Float,b:Float){
  Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);Matrix.scaleM(model,0,sx,sy,sz)
  val mvp=FloatArray(16);Matrix.multiplyMM(mvp,0,vp,0,model,0)
  GLES20.glUseProgram(program);val p=GLES20.glGetAttribLocation(program,"aPosition")
  GLES20.glEnableVertexAttribArray(p);GLES20.glVertexAttribPointer(p,3,GLES20.GL_FLOAT,false,0,m.v)
  GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"uMvp"),1,false,mvp,0)
  GLES20.glUniform4f(GLES20.glGetUniformLocation(program,"uColor"),r,g,b,1f)
  GLES20.glDrawArrays(m.mode,0,m.count);GLES20.glDisableVertexAttribArray(p)
 }
 private fun program(v:String,f:String):Int {
  fun sh(t:Int,s:String):Int {val id=GLES20.glCreateShader(t);GLES20.glShaderSource(id,s);GLES20.glCompileShader(id);return id}
  val p=GLES20.glCreateProgram();GLES20.glAttachShader(p,sh(GLES20.GL_VERTEX_SHADER,v));GLES20.glAttachShader(p,sh(GLES20.GL_FRAGMENT_SHADER,f));GLES20.glLinkProgram(p);return p
 }
 private class Mesh(val v:FloatBuffer,val count:Int,val mode:Int) {
  companion object {
   private fun make(a:FloatArray,mode:Int):Mesh {val b=ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer();b.put(a).position(0);return Mesh(b,a.size/3,mode)}
   fun cube():Mesh {
    val a=floatArrayOf(-1f,-1f,1f,1f,-1f,1f,1f,1f,1f,-1f,-1f,1f,1f,1f,1f,-1f,1f,1f,-1f,-1f,-1f,-1f,1f,-1f,1f,1f,-1f,-1f,-1f,-1f,1f,1f,-1f,1f,-1f,-1f,-1f,1f,-1f,-1f,1f,1f,-1f,1f,1f,-1f,1f,1f,-1f,-1f,-1f,1f,-1f,-1f,-1f,1f,1f,-1f,-1f,-1f,1f,1f,1f,-1f,1f,-1f,-1f,-1f,-1f,1f,-1f,1f,1f,1f,1f,-1f,-1f,-1f,1f,-1f,1f,1f,1f,-1f,-1f,-1f,1f,1f,1f,-1f,-1f,-1f,-1f,-1f,1f,-1f,1f,1f,-1f,-1f,-1f,-1f,1f,1f,-1f,1f,-1f)
    return make(a,GLES20.GL_TRIANGLES)
   }
   fun sphere():Mesh {
    val a=ArrayList<Float>();val lat=10;val lon=14
    for(i in 0 until lat)for(j in 0 until lon){
     val a0=Math.PI*i/lat;val a1=Math.PI*(i+1)/lat;val b0=2*Math.PI*j/lon;val b1=2*Math.PI*(j+1)/lon
     fun v(aa:Double,bb:Double){a.add((sin(aa)*cos(bb)).toFloat());a.add(cos(aa).toFloat());a.add((sin(aa)*sin(bb)).toFloat())}
     v(a0,b0);v(a1,b0);v(a1,b1);v(a0,b0);v(a1,b1);v(a0,b1)
    };return make(a.toFloatArray(),GLES20.GL_TRIANGLES)
   }
   fun ring():Mesh {val a=ArrayList<Float>();for(i in 0 until 48){val x=2*Math.PI*i/48;val y=2*Math.PI*(i+1)/48;a.add(cos(x).toFloat());a.add(sin(x).toFloat());a.add(0f);a.add(cos(y).toFloat());a.add(sin(y).toFloat());a.add(0f)};return make(a.toFloatArray(),GLES20.GL_LINES)}
  }
 }
}
