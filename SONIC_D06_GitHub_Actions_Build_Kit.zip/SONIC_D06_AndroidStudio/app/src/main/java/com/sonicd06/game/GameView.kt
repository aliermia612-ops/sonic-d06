package com.sonicd06.game
import android.content.Context
import android.opengl.GLSurfaceView
class GameView(context:Context):GLSurfaceView(context) {
 private val renderer=GameRenderer()
 init { setEGLContextClientVersion(2); setRenderer(renderer); renderMode=RENDERMODE_CONTINUOUSLY }
 fun setControl(n:String,d:Boolean)=renderer.controls(n,d)
}
